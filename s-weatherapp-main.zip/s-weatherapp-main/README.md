# s-weatherapp
DEMO-LINK:  [WeatherApp](https://s-weatherapp.netlify.app/)
